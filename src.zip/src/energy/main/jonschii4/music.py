import sys
import os
import math
import random
import threading
import time

import pygame
import numpy as np

try:
    import tkinter as tk
    from tkinter import filedialog
except Exception:
    tk = None


def choose_file_via_dialog():
    if tk is None:
        return None
    root = tk.Tk()
    root.withdraw()
    path = filedialog.askopenfilename(title="Select sound file",
                                      filetypes=[("WAV/OGG/MP3","*.wav *.ogg *.mp3"), ("All files","*.*")])
    root.destroy()
    return path


class FireworkParticle:
    def __init__(self, pos, color):
        self.pos = np.array(pos, dtype=float)
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(1, 5)
        self.vel = np.array([math.cos(angle) * speed, math.sin(angle) * speed])
        self.life = random.uniform(800, 1600)
        self.birth = pygame.time.get_ticks()
        self.color = color

    def update(self, dt):
        self.vel[1] += 0.01 * dt
        self.pos += self.vel * (dt / 16)

    def draw(self, surf):
        age = pygame.time.get_ticks() - self.birth
        t = max(0, 1 - age / self.life)
        if t <= 0:
            return
        c = tuple(min(255, int(k * t)) for k in self.color)
        r = max(1, int(3 * t))
        pygame.draw.circle(surf, c, (int(self.pos[0]), int(self.pos[1])), r)


class Stripe:
    def __init__(self, x, w, color):
        self.x = x
        self.y = 600
        self.w = w
        self.h = random.randint(40, 140)
        self.color = color
        self.speed = random.uniform(1.5, 4)

    def update(self, dt, amp):
        self.y -= self.speed * (1 + amp * 8) * (dt / 16)

    def draw(self, surf):
        rect = pygame.Rect(int(self.x), int(self.y), int(self.w), int(self.h))
        pygame.draw.rect(surf, self.color, rect)


class Stickman:
    def __init__(self, x, y, size=1.0):
        self.x = x
        self.y = y
        self.size = size
        self.color = (30, 180, 255)

    def draw(self, surf, t, amp):
        # bob
        bob = math.sin(t * 2 + amp * 10) * 8 * amp
        head_r = int(10 * self.size + amp * 6)
        head_pos = (int(self.x), int(self.y - 40 * self.size + bob))
        pygame.draw.circle(surf, self.color, head_pos, head_r, 2)

        # body
        body_top = np.array([self.x, self.y - 30 * self.size + bob])
        body_bot = np.array([self.x, self.y + 10 * self.size + bob])
        pygame.draw.line(surf, self.color, body_top, body_bot, 3)

        # arms
        arm_len = 25 * self.size
        aangle = math.sin(t * 4) * 0.8 * (0.5 + amp * 1.5)
        left_arm = (int(self.x - math.cos(aangle) * arm_len), int(self.y - 10 * self.size + math.sin(aangle) * arm_len + bob))
        right_arm = (int(self.x + math.cos(aangle) * arm_len), int(self.y - 10 * self.size - math.sin(aangle) * arm_len + bob))
        pygame.draw.line(surf, self.color, (int(body_top[0]), int(body_top[1])), left_arm, 3)
        pygame.draw.line(surf, self.color, (int(body_top[0]), int(body_top[1])), right_arm, 3)

        # legs
        langle = math.sin(t * 3 + 1) * 0.8 * (0.5 + amp * 1.5)
        left_leg = (int(self.x - math.cos(langle) * arm_len), int(self.y + 40 * self.size + math.sin(langle) * arm_len + bob))
        right_leg = (int(self.x + math.cos(langle) * arm_len), int(self.y + 40 * self.size - math.sin(langle) * arm_len + bob))
        pygame.draw.line(surf, self.color, (int(body_bot[0]), int(body_bot[1])), left_leg, 3)
        pygame.draw.line(surf, self.color, (int(body_bot[0]), int(body_bot[1])), right_leg, 3)


def compute_envelope(samples, frame_size=2048):
    if samples.ndim > 1:
        samples = samples.mean(axis=1)
    samples = samples.astype(np.float32)
    # normalize
    maxv = np.max(np.abs(samples))
    if maxv > 0:
        samples /= maxv
    # RMS per frame
    num_frames = max(1, len(samples) // frame_size)
    env = np.zeros(num_frames, dtype=np.float32)
    for i in range(num_frames):
        a = samples[i * frame_size:(i + 1) * frame_size]
        env[i] = np.sqrt(np.mean(a * a)) if a.size > 0 else 0
    # smooth
    env = np.convolve(env, np.ones(4) / 4, mode='same')
    # normalize to 0-1
    if env.max() > 0:
        env /= env.max()
    return env, frame_size


def main(sound_path=None):
    if sound_path is None:
        if len(sys.argv) > 1:
            sound_path = sys.argv[1]
        else:
            sound_path = choose_file_via_dialog()

    if not sound_path or not os.path.exists(sound_path):
        print("No sound file provided or found. Provide a path as argv or select a file.")
        return

    pygame.mixer.pre_init(44100, -16, 2, 2048)
    pygame.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Energy Visualizer")
    clock = pygame.time.Clock()

    # Load sound (preload)
    try:
        sound = pygame.mixer.Sound(sound_path)
    except Exception as e:
        print("Failed to load sound:", e)
        return

    try:
        samples = pygame.sndarray.array(sound)
    except Exception:
        # Fallback: try using pygame.mixer.Sound to get raw; if fails we will not compute envelope
        samples = np.zeros(1, dtype=np.int16)

    sample_rate = pygame.mixer.get_init()[0]
    envelope, frame_size = compute_envelope(samples, frame_size=2048)

    font = pygame.font.SysFont(None, 36)

    button_rect = pygame.Rect(320, 260, 160, 60)
    button_enabled = True
    playing = False
    start_ticks = 0

    particles = []
    stripes = []

    stick = Stickman(400, 380, size=1.6)

    bg_colors = [(0,0,0),(20,0,60),(10,10,10),(80,0,120),(0,40,60)]
    bg_index = 0
    last_flash = 0

    running = True
    while running:
        dt = clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if button_enabled and button_rect.collidepoint(event.pos):
                    # start
                    sound.play()
                    button_enabled = False
                    playing = True
                    start_ticks = pygame.time.get_ticks()

        # compute amplitude based on playback position
        amp = 0.0
        if playing:
            pos_ms = pygame.time.get_ticks() - start_ticks
            # map ms to frame index
            sec = pos_ms / 1000.0
            frame_idx = int((sec * sample_rate) / frame_size)
            if frame_idx < len(envelope):
                amp = float(envelope[frame_idx])
            else:
                amp = 0.0

        # background flashing
        if playing and pygame.time.get_ticks() - last_flash > 120:
            bg_index = (bg_index + 1) % len(bg_colors)
            last_flash = pygame.time.get_ticks()

        bg = bg_colors[bg_index] if playing else (0,0,0)
        screen.fill(bg)

        # Draw neon yellow stripes (rising)
        if playing and random.random() < 0.12 + amp * 0.4:
            x = random.randint(0, 780)
            w = random.randint(4, 12)
            stripes.append(Stripe(x, w, (255, 240, 60)))

        for s in stripes[:]:
            s.update(dt, amp)
            s.draw(screen)
            if s.y + s.h < 0:
                stripes.remove(s)

        # Fireworks spawn
        if playing and amp > 0.55 and random.random() < amp * 0.08:
            cx = random.randint(100, 700)
            cy = random.randint(50, 300)
            color = (random.randint(160,255), random.randint(80,255), random.randint(80,255))
            for _ in range(18):
                particles.append(FireworkParticle((cx, cy), color))

        for p in particles[:]:
            p.update(dt)
            p.draw(screen)
            if pygame.time.get_ticks() - p.birth > p.life:
                particles.remove(p)

        # draw stickman dancing
        t = pygame.time.get_ticks() / 1000.0
        if playing:
            stick.draw(screen, t, amp)
        else:
            stick.draw(screen, t, 0)

        # draw button (disabled while playing)
        btn_col = (100, 100, 100) if not button_enabled else (10, 220, 100)
        pygame.draw.rect(screen, btn_col, button_rect, border_radius=8)
        txt = font.render("Energy", True, (0,0,0) if button_enabled else (40,40,40))
        screen.blit(txt, (button_rect.x + (button_rect.w - txt.get_width()) // 2,
                          button_rect.y + (button_rect.h - txt.get_height()) // 2))

        # neon outline during playing
        if playing:
            outline_surf = pygame.Surface((800,600), pygame.SRCALPHA)
            glow = pygame.Surface((800,600), pygame.SRCALPHA)
            glow.fill((0,0,0,0))
            pygame.draw.circle(glow, (30,180,255,30), (400,200), int(120 + amp * 200))
            screen.blit(glow, (0,0), special_flags=pygame.BLEND_ADD)

        pygame.display.flip()

        # check if sound finished
        if playing and pygame.mixer.get_busy() == 0:
            playing = False
            button_enabled = True

    pygame.quit()


if __name__ == '__main__':
    path = None
    if len(sys.argv) > 1:
        path = sys.argv[1]
    main(path)
import sys
import os
import tkinter as tk
import pygame

pygame.init()
pygame.mixer.init()

# Set sound path here or pass as first CLI argument: python music.py path/to/sound.wav
SOUND_PATH = ".\\src\\energy\\main\\jonschii4\\energy_music.wav"
if len(sys.argv) > 1:
	SOUND_PATH = sys.argv[1]

try:
	sound = pygame.mixer.Sound(SOUND_PATH)
except Exception as e:
	print(f"Warning: failed to load sound '{SOUND_PATH}':", e)
	sound = None

def create_gui():
	root = tk.Tk()
	root.title("Energy GUI")
	root.geometry("420x260")

	default_bg = root.cget("bg")

	btn = tk.Button(root, text="energy", font=("Helvetica", 18), width=10, height=2)
	btn.pack(expand=True)

	btn_default_bg = btn.cget("bg")

	colors = ["#ff0000", "#00ff00", "#0000ff", "#ffff00", "#ff00ff", "#00ffff", "#ffffff"]
	flash_interval = 100  # ms

	def start_flashing(duration_s):
		steps = max(1, int(duration_s * 1000 / flash_interval))
		def step(i):
			if i <= 0:
				root.config(bg=default_bg)
				btn.config(bg=btn_default_bg, state="normal")
				return
			color = colors[i % len(colors)]
			root.config(bg=color)
			btn.config(bg=color)
			root.after(flash_interval, lambda: step(i-1))
		step(steps)

	def on_energy():
		btn.config(state="disabled")
		if sound:
			channel = sound.play()
			duration = sound.get_length()
		else:
			duration = 3.0
		start_flashing(duration)

	btn.config(command=on_energy)

	return root

if __name__ == "__main__":
	app = create_gui()
	app.mainloop()